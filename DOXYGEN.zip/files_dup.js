var files_dup =
[
    [ "Carta.java", "_carta_8java.html", "_carta_8java" ],
    [ "CartaEspecial.java", "_carta_especial_8java.html", "_carta_especial_8java" ],
    [ "GUI.java", "_g_u_i_8java.html", "_g_u_i_8java" ],
    [ "Juego.java", "_juego_8java.html", "_juego_8java" ],
    [ "Jugador.java", "_jugador_8java.html", "_jugador_8java" ],
    [ "Main.java", "_main_8java.html", "_main_8java" ],
    [ "Mazo.java", "_mazo_8java.html", "_mazo_8java" ],
    [ "Pruebas.java", "_pruebas_8java.html", "_pruebas_8java" ]
];