var _pruebas_8java =
[
    [ "Pruebas", "class_pruebas.html", null ]
];