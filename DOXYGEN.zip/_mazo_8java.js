var _mazo_8java =
[
    [ "Mazo", "class_mazo.html", "class_mazo" ]
];