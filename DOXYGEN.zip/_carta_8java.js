var _carta_8java =
[
    [ "Carta", "class_carta.html", "class_carta" ]
];