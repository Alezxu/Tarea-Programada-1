var annotated_dup =
[
    [ "Carta", "class_carta.html", "class_carta" ],
    [ "CartaEspecial", "class_carta_especial.html", "class_carta_especial" ],
    [ "GUI", "class_g_u_i.html", "class_g_u_i" ],
    [ "Juego", "class_juego.html", "class_juego" ],
    [ "Jugador", "class_jugador.html", "class_jugador" ],
    [ "Main", "class_main.html", null ],
    [ "Mazo", "class_mazo.html", "class_mazo" ],
    [ "Pruebas", "class_pruebas.html", null ]
];