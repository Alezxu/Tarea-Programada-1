var _jugador_8java =
[
    [ "Jugador", "class_jugador.html", "class_jugador" ]
];