var class_carta =
[
    [ "Carta", "class_carta.html#afa467702402cc47f94c33f964d0a79cf", null ],
    [ "Carta", "class_carta.html#aa7ec26c924ce4c20bb69326d166af06f", null ],
    [ "comparar", "class_carta.html#a94a5570dfc262baee6a64ef866351e3e", null ],
    [ "esCartaEspecial", "class_carta.html#a2b7df35ab315324146469efad6e5aafa", null ],
    [ "getcolor", "class_carta.html#a11fd1db7c923104a7c9527a993d6e049", null ],
    [ "getNumero", "class_carta.html#a35ab274a12eb57e72ce1bce1f30958a9", null ],
    [ "imprimir", "class_carta.html#aa40ae5d64c5d608b1b752c9cbf24c759", null ],
    [ "imprimir2", "class_carta.html#accd089b22a28097d18674481f4af1042", null ],
    [ "setcolor", "class_carta.html#afa34b44ae22bbf0e20d2d10ae44e9e4d", null ],
    [ "setNumero", "class_carta.html#a459584103d43a6aa38bcdd04802d45c0", null ]
];