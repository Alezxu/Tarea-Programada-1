var class_juego =
[
    [ "Juego", "class_juego.html#ace84a65ebc21c85543fea073fa541a99", null ],
    [ "buscarCarta", "class_juego.html#aad0067b56736db15345e7afd5c43ebc6", null ],
    [ "buscarCartaBot", "class_juego.html#a8254870fcba0fd6a7c7c633b7612fb04", null ],
    [ "cancelarComa", "class_juego.html#a12ae2c2ad9489bd66751b5672bdecdeb", null ],
    [ "cardPlay", "class_juego.html#a6cdfbcbdc682d370771d75553bf397a1", null ],
    [ "cardPlayBot", "class_juego.html#a540aff38d7f73cf855912b5b6297a1e7", null ],
    [ "cartaInicial", "class_juego.html#ae7fafccadce27cb2d58de31db24f8643", null ],
    [ "empezarJuegoPVE", "class_juego.html#ad196151842c722703f9951df203f07cb", null ],
    [ "empezarJuegoPVP", "class_juego.html#ae0656fe8074b6f564af3f550781479f3", null ],
    [ "getCartaEnJuego", "class_juego.html#aa768fe5d14e51c058639a06596e20151", null ],
    [ "getIndiceCartaEnJuego", "class_juego.html#a6dd9cdab344faec583f857f5909012f4", null ],
    [ "imprimirCartaEnJuego", "class_juego.html#a19e65afdbf7e7f5f3203433ccb8f68a8", null ],
    [ "imprimirMazoEnJuego", "class_juego.html#a00cbd175ff14204800528d282b625413", null ]
];