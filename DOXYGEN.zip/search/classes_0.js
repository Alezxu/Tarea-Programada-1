var searchData=
[
  ['carta_0',['Carta',['../class_carta.html',1,'']]],
  ['cartaespecial_1',['CartaEspecial',['../class_carta_especial.html',1,'']]]
];
