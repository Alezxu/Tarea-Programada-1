var searchData=
[
  ['asignartipoespecial_0',['asignarTipoEspecial',['../class_carta_especial.html#a3b94433ecf123295fd605fe7b91684f2',1,'CartaEspecial']]]
];
