var searchData=
[
  ['1_0',['Tarea-Programada-1',['../md__r_e_a_d_m_e.html',1,'']]]
];
