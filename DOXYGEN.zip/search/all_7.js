var searchData=
[
  ['imprimir_0',['imprimir',['../class_carta.html#aa40ae5d64c5d608b1b752c9cbf24c759',1,'Carta.imprimir()'],['../class_mazo.html#a98cc98746ac3dea137bb7bef1801995c',1,'Mazo.imprimir()']]],
  ['imprimir2_1',['imprimir2',['../class_carta.html#accd089b22a28097d18674481f4af1042',1,'Carta']]],
  ['imprimircartaenjuego_2',['imprimirCartaEnJuego',['../class_juego.html#a19e65afdbf7e7f5f3203433ccb8f68a8',1,'Juego']]],
  ['imprimirjugador_3',['imprimirJugador',['../class_jugador.html#ac6572fcd1ba0e838e59b76235d951d20',1,'Jugador']]],
  ['imprimirmazoenjuego_4',['imprimirMazoEnJuego',['../class_juego.html#a00cbd175ff14204800528d282b625413',1,'Juego']]]
];
