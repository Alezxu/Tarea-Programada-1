var searchData=
[
  ['cancelarcoma_0',['cancelarComa',['../class_juego.html#a12ae2c2ad9489bd66751b5672bdecdeb',1,'Juego']]],
  ['cardplay_1',['cardPlay',['../class_juego.html#a6cdfbcbdc682d370771d75553bf397a1',1,'Juego']]],
  ['cardplaybot_2',['cardPlayBot',['../class_juego.html#a540aff38d7f73cf855912b5b6297a1e7',1,'Juego']]],
  ['carta_3',['Carta',['../class_carta.html',1,'Carta'],['../class_carta.html#afa467702402cc47f94c33f964d0a79cf',1,'Carta.Carta()'],['../class_carta.html#aa7ec26c924ce4c20bb69326d166af06f',1,'Carta.Carta(int numero, String color)']]],
  ['carta_2ejava_4',['Carta.java',['../_carta_8java.html',1,'']]],
  ['cartaespecial_5',['CartaEspecial',['../class_carta_especial.html',1,'CartaEspecial'],['../class_carta_especial.html#a6097193f1531b9ffb7a557441e3e888d',1,'CartaEspecial.CartaEspecial()']]],
  ['cartaespecial_2ejava_6',['CartaEspecial.java',['../_carta_especial_8java.html',1,'']]],
  ['cartainicial_7',['cartaInicial',['../class_juego.html#ae7fafccadce27cb2d58de31db24f8643',1,'Juego']]],
  ['cartasiniciales_8',['cartasIniciales',['../class_jugador.html#a809cf7dd65c60820bb4225ece91244a2',1,'Jugador']]],
  ['coma_9',['coma',['../class_jugador.html#aab9645472606e1cd9902e1323afe2ef3',1,'Jugador']]],
  ['comparar_10',['comparar',['../class_carta.html#a94a5570dfc262baee6a64ef866351e3e',1,'Carta']]]
];
