var searchData=
[
  ['limpiarpantalla_0',['limpiarPantalla',['../class_g_u_i.html#ac876d66cfda1cf30fa88c804f9608a9e',1,'GUI']]]
];
