var searchData=
[
  ['buscarcarta_0',['buscarCarta',['../class_juego.html#aad0067b56736db15345e7afd5c43ebc6',1,'Juego']]],
  ['buscarcartabot_1',['buscarCartaBot',['../class_juego.html#a8254870fcba0fd6a7c7c633b7612fb04',1,'Juego']]]
];
