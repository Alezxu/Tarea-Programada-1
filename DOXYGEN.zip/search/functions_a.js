var searchData=
[
  ['pausa_0',['pausa',['../class_g_u_i.html#a7fa5c62798f069381ff6e8d98fb1c8c6',1,'GUI']]],
  ['pruebacarta_1',['pruebaCarta',['../class_pruebas.html#a22e0df03d838230963faab0fbd44e038',1,'Pruebas']]],
  ['pruebacartaespecial_2',['pruebaCartaEspecial',['../class_pruebas.html#a46734200b98e38a2c60c0aa402576887',1,'Pruebas']]],
  ['pruebajuegobasico_3',['pruebaJuegoBasico',['../class_pruebas.html#a6b57792bcc55c787de45ab7321542b2e',1,'Pruebas']]],
  ['pruebajugador_4',['pruebaJugador',['../class_pruebas.html#ac7618bd484196864dd7c280fcc04a55f',1,'Pruebas']]],
  ['pruebamazo_5',['pruebaMazo',['../class_pruebas.html#adb7e9cab9f17d14734637fba5dfe86e3',1,'Pruebas']]]
];
