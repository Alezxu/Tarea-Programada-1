var searchData=
[
  ['descartarcartas_0',['descartarCartas',['../class_jugador.html#a9ead880823d1f3614cdeadcca1e87738',1,'Jugador']]]
];
