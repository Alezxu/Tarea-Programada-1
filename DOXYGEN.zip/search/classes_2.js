var searchData=
[
  ['juego_0',['Juego',['../class_juego.html',1,'']]],
  ['jugador_1',['Jugador',['../class_jugador.html',1,'']]]
];
