var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['repartircartas_1',['repartirCartas',['../class_mazo.html#a7305b7d1fa8efef1cd9891a7d181bdcb',1,'Mazo']]],
  ['revolver_2',['revolver',['../class_mazo.html#a892baf82f3c8a4adff3819a51c91e1bf',1,'Mazo']]]
];
