var searchData=
[
  ['main_0',['main',['../class_main.html#a8a5d0f827edddff706cc0e6740d0579a',1,'Main.main()'],['../class_pruebas.html#a5f13ba2325e3a81858ea078e75580675',1,'Pruebas.main()']]],
  ['mazo_1',['Mazo',['../class_mazo.html#afa403ed1e1889747ffd1bc36899785b9',1,'Mazo']]],
  ['menuprincipal_2',['menuPrincipal',['../class_g_u_i.html#a97fe491af92029d0721d2d965be4c5a0',1,'GUI']]]
];
