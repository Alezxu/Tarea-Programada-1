var searchData=
[
  ['getcartaenjuego_0',['getCartaEnJuego',['../class_juego.html#aa768fe5d14e51c058639a06596e20151',1,'Juego']]],
  ['getcartasrestantes_1',['getCartasRestantes',['../class_mazo.html#a4843486cdd5e71f5fe4ef01fb17cb0f8',1,'Mazo']]],
  ['getcolor_2',['getcolor',['../class_carta.html#a11fd1db7c923104a7c9527a993d6e049',1,'Carta']]],
  ['getindicecartaenjuego_3',['getIndiceCartaEnJuego',['../class_juego.html#a6dd9cdab344faec583f857f5909012f4',1,'Juego']]],
  ['getmano_4',['getMano',['../class_jugador.html#a345013072e1cf1b150216faf3638e528',1,'Jugador']]],
  ['getnumero_5',['getNumero',['../class_carta.html#a35ab274a12eb57e72ce1bce1f30958a9',1,'Carta']]],
  ['gettamaniomano_6',['getTamanioMano',['../class_jugador.html#a12e2e29d1fcc489af06b6c2771e08890',1,'Jugador']]],
  ['gui_7',['GUI',['../class_g_u_i.html',1,'']]],
  ['gui_2ejava_8',['GUI.java',['../_g_u_i_8java.html',1,'']]]
];
