var searchData=
[
  ['juego_0',['Juego',['../class_juego.html',1,'Juego'],['../class_juego.html#ace84a65ebc21c85543fea073fa541a99',1,'Juego.Juego()']]],
  ['juego_2ejava_1',['Juego.java',['../_juego_8java.html',1,'']]],
  ['jugador_2',['Jugador',['../class_jugador.html',1,'']]],
  ['jugador_2ejava_3',['Jugador.java',['../_jugador_8java.html',1,'']]]
];
