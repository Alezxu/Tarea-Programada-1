var searchData=
[
  ['repartircartas_0',['repartirCartas',['../class_mazo.html#a7305b7d1fa8efef1cd9891a7d181bdcb',1,'Mazo']]],
  ['revolver_1',['revolver',['../class_mazo.html#a892baf82f3c8a4adff3819a51c91e1bf',1,'Mazo']]]
];
