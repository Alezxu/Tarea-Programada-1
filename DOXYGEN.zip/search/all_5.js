var searchData=
[
  ['empezarjuegopve_0',['empezarJuegoPVE',['../class_juego.html#ad196151842c722703f9951df203f07cb',1,'Juego']]],
  ['empezarjuegopvp_1',['empezarJuegoPVP',['../class_juego.html#ae0656fe8074b6f564af3f550781479f3',1,'Juego']]],
  ['escartaespecial_2',['esCartaEspecial',['../class_carta.html#a2b7df35ab315324146469efad6e5aafa',1,'Carta']]]
];
