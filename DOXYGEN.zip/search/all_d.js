var searchData=
[
  ['setcolor_0',['setcolor',['../class_carta.html#afa34b44ae22bbf0e20d2d10ae44e9e4d',1,'Carta']]],
  ['setnumero_1',['setNumero',['../class_carta.html#a459584103d43a6aa38bcdd04802d45c0',1,'Carta']]]
];
