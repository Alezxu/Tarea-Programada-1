var searchData=
[
  ['verificarvictoria_0',['verificarVictoria',['../class_jugador.html#a0e4308a0d6cd52b5651f488f410700b9',1,'Jugador']]],
  ['volverajugar_1',['volverAJugar',['../class_g_u_i.html#aaf35481b35578f1b8cf4e55e8fe9a491',1,'GUI']]]
];
