var class_carta_especial =
[
    [ "CartaEspecial", "class_carta_especial.html#a6097193f1531b9ffb7a557441e3e888d", null ],
    [ "asignarTipoEspecial", "class_carta_especial.html#a3b94433ecf123295fd605fe7b91684f2", null ]
];