var class_mazo =
[
    [ "Mazo", "class_mazo.html#afa403ed1e1889747ffd1bc36899785b9", null ],
    [ "getCartasRestantes", "class_mazo.html#a4843486cdd5e71f5fe4ef01fb17cb0f8", null ],
    [ "imprimir", "class_mazo.html#a98cc98746ac3dea137bb7bef1801995c", null ],
    [ "repartirCartas", "class_mazo.html#a7305b7d1fa8efef1cd9891a7d181bdcb", null ],
    [ "revolver", "class_mazo.html#a892baf82f3c8a4adff3819a51c91e1bf", null ]
];