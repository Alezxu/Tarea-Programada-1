var class_jugador =
[
    [ "cartasIniciales", "class_jugador.html#a809cf7dd65c60820bb4225ece91244a2", null ],
    [ "coma", "class_jugador.html#aab9645472606e1cd9902e1323afe2ef3", null ],
    [ "descartarCartas", "class_jugador.html#a9ead880823d1f3614cdeadcca1e87738", null ],
    [ "getMano", "class_jugador.html#a345013072e1cf1b150216faf3638e528", null ],
    [ "getTamanioMano", "class_jugador.html#a12e2e29d1fcc489af06b6c2771e08890", null ],
    [ "imprimirJugador", "class_jugador.html#ac6572fcd1ba0e838e59b76235d951d20", null ],
    [ "verificarVictoria", "class_jugador.html#a0e4308a0d6cd52b5651f488f410700b9", null ]
];