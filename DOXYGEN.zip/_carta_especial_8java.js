var _carta_especial_8java =
[
    [ "CartaEspecial", "class_carta_especial.html", "class_carta_especial" ]
];